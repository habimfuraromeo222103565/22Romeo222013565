/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loginandregister;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author HABIMFURA Romeo
 */
public class DBConnection {
    public static Connection connect() {
        Connection conn;
        conn = null;
       
      try{
          Class.forName("com.mysql.jdbc.Driver");
          conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mytest","romeo", "romeo");
        }catch( ClassNotFoundException | SQLException ex){
  
           System.out.print("There are errors with database");
        }
      return conn;
    }
    
}
